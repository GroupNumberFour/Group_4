/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package project251;

import java.util.Scanner;

/**
 *
 * @author rawan
 */
public class justTry {


    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        FileHandler fileHandler = new FileHandler();

        // إضافة نموذج تجريبي
        Form form1 = new Form(1, "Old Muni", "C-123", "Old District",
                "24.123, 46.456", "2025-01-01", "Old Subject", "Old Notes");
        fileHandler.addForm(form1);

        // إنشاء موظف
        Employee emp = new Employee("E001", "Fahad");

        // إدخال رقم الفورم
        System.out.print("Enter Form ID to update: ");
        int formId = Integer.parseInt(input.nextLine());

        // الموظف يختار التعديلات (أي قيمة يتركها فاضية، ما تتغير)
        System.out.println("Enter new values (leave blank to skip):");

        System.out.print("Municipality: ");
        String municipality = getOptionalInput(input);

        System.out.print("Contract: ");
        String contract = getOptionalInput(input);

        System.out.print("District: ");
        String district = getOptionalInput(input);

        System.out.print("Coordinates: ");
        String coordinates = getOptionalInput(input);

        System.out.print("Report Date: ");
        String reportDate = getOptionalInput(input);

        System.out.print("Subject: ");
        String subject = getOptionalInput(input);

        System.out.print("Notes: ");
        String notes = getOptionalInput(input);

        // تنفيذ التحديث
        emp.updateForm(fileHandler, formId, municipality, contract, district, coordinates, reportDate, subject, notes);

        // عرض الفورم بعد التحديث
        Form updated = fileHandler.selectForm(formId);
        if (updated != null) {
            System.out.println("\n--- Updated Form ---");
            System.out.println("Municipality: " + updated.getMunicipality());
            System.out.println("Contract: " + updated.getContract());
            System.out.println("District: " + updated.getDistrict());
            System.out.println("Coordinates: " + updated.getCoordinates());
            System.out.println("Report Date: " + updated.getReportDate());
            System.out.println("Subject: " + updated.getSubject());
            System.out.println("Notes: " + updated.getNotes());
        }
    }

    // دالة ترجع null إذا الإدخال فاضي
    private static String getOptionalInput(Scanner input) {
        String line = input.nextLine();
        return line.isEmpty() ? null : line;
    }
}

    

